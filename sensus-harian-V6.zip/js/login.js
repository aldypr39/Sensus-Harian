// js/login.js
import { DataManager, dataStore } from './modules/dataManager.js';

document.addEventListener('DOMContentLoaded', () => {
  DataManager.load();
  const form = document.querySelector('form');
  const inpUser = document.getElementById('login-username');
  const inpPass = document.getElementById('login-password');

  form.addEventListener('submit', e => {
    e.preventDefault();
    // Muat data yang tersimpan
    

    const username = inpUser.value.trim();
    const password = inpPass.value;

    // Cari user dengan username+password cocok
    const user = dataStore.users.find(u => 
      u.username === username && u.password === password
    );

    if (user) {
      // Simpan sebagai yang sedang login
      dataStore.current_user = user;
      DataManager.save();
      // Redirect ke dashboard
      window.location.href = 'index.html';
    } else {
      // Gagal login
      alert('Username atau password salah!');
      inpPass.value = '';
      inpPass.focus();
    }
  });
});
